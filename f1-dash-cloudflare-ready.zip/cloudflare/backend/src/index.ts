import { Container, getContainer } from "@cloudflare/containers";

const API_ORIGIN = "https://f1-dash-web.YOUR-SUBDOMAIN.workers.dev";

export class ApiContainer extends Container {
  defaultPort = 80;
  sleepAfter = "30m";
  envVars = {
    ADDRESS: "0.0.0.0:80",
    RUST_LOG: "api=info"
  };
}

export class RealtimeContainer extends Container {
  defaultPort = 80;
  sleepAfter = "2h";
  envVars = {
    ADDRESS: "0.0.0.0:80",
    RUST_LOG: "realtime=info",
    ORIGIN: API_ORIGIN
  };
}

function cors(response: Response, request: Request) {
  const headers = new Headers(response.headers);
  const origin = request.headers.get("Origin");
  if (origin === API_ORIGIN || !origin) {
    headers.set("Access-Control-Allow-Origin", origin ?? API_ORIGIN);
  }
  headers.set("Vary", "Origin");
  headers.set("Access-Control-Allow-Methods", "GET, OPTIONS");
  headers.set("Access-Control-Allow-Headers", "Content-Type");
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: {
        "Access-Control-Allow-Origin": request.headers.get("Origin") ?? API_ORIGIN,
        "Access-Control-Allow-Methods": "GET, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Max-Age": "86400"
      }});
    }

    const realtime =
      url.pathname === "/api/realtime" ||
      url.pathname === "/api/drivers" ||
      url.pathname === "/api/current" ||
      url.pathname === "/api/connections";

    const container = realtime
      ? getContainer(env.REALTIME_CONTAINER, "f1-realtime")
      : getContainer(env.API_CONTAINER, "f1-api");

    const response = await container.fetch(request);
    return cors(response, request);
  }
};
