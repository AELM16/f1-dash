# Cloudflare backend

This Worker runs the existing Rust API and realtime services as Cloudflare Containers.

## Deploy

Cloudflare Workers Containers require a Workers Paid plan.

From this directory:

```bash
npm install
npx wrangler login
npx wrangler deploy
```

The first deployment can take several minutes while the container images are built and provisioned.

Then set the resulting Worker URL in `dashboard/wrangler.jsonc` (or as Cloudflare Worker variables):

- `NEXT_PUBLIC_LIVE_URL`
- `API_URL`

Before production, replace `YOUR-SUBDOMAIN` in `src/index.ts` with the real web Worker URL so the realtime service's CORS origin is correct.

## Local development

Docker must be running:

```bash
npm install
npx wrangler dev
```
