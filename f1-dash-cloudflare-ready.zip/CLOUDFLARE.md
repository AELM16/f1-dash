# Cloudflare deployment

This repository is prepared for Cloudflare Workers.

## Architecture

- `dashboard/` -> Next.js deployed to a Cloudflare Worker using OpenNext.
- `cloudflare/backend/` -> one Cloudflare Worker that routes requests to two Cloudflare Containers:
  - Rust API
  - Rust realtime service
- The Rust applications remain unchanged apart from being containerized.

Cloudflare Containers are used because the existing API/realtime services are Tokio/Axum Linux processes and cannot simply be copied into a normal JavaScript Worker.

## One-time setup

1. Create a Cloudflare account on a Workers Paid plan.
2. Create a Cloudflare API token that can deploy Workers and Containers.
3. Add these GitHub repository secrets:
   - `CLOUDFLARE_API_TOKEN`
   - `CLOUDFLARE_ACCOUNT_ID`
4. After the backend is deployed, copy its `*.workers.dev` URL.
5. Set GitHub repository variables:
   - `API_URL` = backend Worker URL
   - `NEXT_PUBLIC_LIVE_URL` = backend Worker URL
6. Replace `API_ORIGIN` in `cloudflare/backend/src/index.ts` with the deployed web Worker URL.
7. Deploy the backend once more, then deploy the web Worker.

Cloudflare's current documentation recommends Wrangler configuration files and supports Workers Builds for Git-based deployment. The repository workflows above use Wrangler directly from GitHub Actions.
